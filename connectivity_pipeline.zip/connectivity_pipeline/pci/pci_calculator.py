"""
File 7: PCI Calculator
======================
Hansen accessibility model + final PCI score computation.
Active street bonus (lambda) and park masking are user-configurable.
Beta can be set globally or per mode.
"""

import numpy as np
import pandas as pd
import geopandas as gpd
import networkx as nx
from scipy.spatial import cKDTree
from typing import Dict, Optional

from core.h3_helper import HexGrid
from core.mass_calculator import MassCalculator
from core.network_builder import MultiModalNetworkBuilder


# ---------------------------------------------------------------------------
# Hansen Accessibility Model
# ---------------------------------------------------------------------------

class HansenAccessibilityModel:
    """
    Computes Hansen gravity-type accessibility:

        A_i = Σ_j  M_j × exp(-β × t_ij) × CostAdjustment_ij

    where:
        M_j   = attractiveness (topographic mass) of destination j
        t_ij  = travel time (minutes) from i to j
        β     = distance decay coefficient (user-configurable, per mode)
        CostAdjustment = income-weighted travel cost penalty
    """

    def __init__(
        self,
        grid: HexGrid,
        network_builder: MultiModalNetworkBuilder,
        mass_calculator: MassCalculator,
    ):
        self.grid   = grid
        self.net    = network_builder
        self.mass   = mass_calculator
        self.hex_ids = grid.gdf["hex_id"].tolist()

        self._hex_to_node: Dict[str, int] = {}
        self._travel_times: Optional[Dict[str, Dict[str, float]]] = None  # {origin_hex: {dest_hex: min}}
        self._accessibility: Optional[pd.Series] = None

    # ------------------------------------------------------------------
    # Step 1: compute travel times
    # ------------------------------------------------------------------

    def compute_travel_times(self, max_time: float = 90.0):
        """
        Compute shortest-path travel times between all hex pairs
        using the unified multi-modal graph.

        Results cached in self._travel_times.
        """
        print(f"⏱  Computing travel times (max {max_time} min)...")
        G = self.net.unified_graph
        if G is None:
            raise RuntimeError("Network not built. Call network_builder.build_all_networks() first.")

        # Map each hex centroid to its nearest network node
        centroids = self.grid.centroids
        coords    = [(r.geometry.y, r.geometry.x) for _, r in centroids.iterrows()]
        hex_id_list = centroids["hex_id"].tolist()
        nearest = self.net.get_nearest_nodes_batch(coords, mode="unified")
        self._hex_to_node = dict(zip(hex_id_list, nearest))

        unique_nodes = list(set(self._hex_to_node.values()))
        # node → list of hex_ids
        node_to_hexes: Dict[int, list] = {}
        for hx, nd in self._hex_to_node.items():
            node_to_hexes.setdefault(nd, []).append(hx)

        travel_times: Dict[str, Dict[str, float]] = {hx: {} for hx in self.hex_ids}
        total = len(unique_nodes)

        for i, source_node in enumerate(unique_nodes):
            if i % 100 == 0:
                print(f"   {i + 1}/{total}...", end="\r")
            try:
                lengths = nx.single_source_dijkstra_path_length(
                    G, source_node, cutoff=max_time, weight="time_min"
                )
            except Exception:
                continue

            # Map node distances back to hex distances
            for dest_node, dist_min in lengths.items():
                for dest_hex in node_to_hexes.get(dest_node, []):
                    for src_hex in node_to_hexes.get(source_node, []):
                        if dist_min < travel_times[src_hex].get(dest_hex, float("inf")):
                            travel_times[src_hex][dest_hex] = dist_min

        self._travel_times = travel_times
        n_pairs = sum(len(v) for v in travel_times.values())
        print(f"\n   ✓ {n_pairs:,} hex-pairs within {max_time} min")

    # ------------------------------------------------------------------
    # Step 2: compute accessibility
    # ------------------------------------------------------------------

    def compute_accessibility(
        self,
        beta: float = 0.08,
        income_data: Optional[pd.Series] = None,
        mode_cost: float = 3.94,
        per_mode_beta: Optional[Dict[str, float]] = None,
    ) -> pd.Series:
        """
        Compute Hansen accessibility score for each hex.

        Parameters
        ----------
        beta         : global decay coefficient (used unless per_mode_beta set)
        income_data  : median household income by hex_id (for cost-of-time)
        mode_cost    : average trip cost in USD (for cost adjustment)
        per_mode_beta: optional dict {mode: beta} to override per mode
        """
        if self._travel_times is None:
            raise RuntimeError("Call compute_travel_times() first.")

        if self.mass._composite is None:
            self.mass.compute_composite_mass()

        mass_values = self.mass._composite.to_dict()

        # Build income-based cost adjustment if income provided
        cost_adj: Dict[str, float] = {}
        if income_data is not None:
            hourly_wage = self.net.median_hourly_wage
            for hx in self.hex_ids:
                inc = income_data.get(hx) if isinstance(income_data, dict) \
                      else income_data.get(hx, np.nan)
                if pd.isna(inc) or inc <= 0:
                    cost_adj[hx] = 1.0
                else:
                    hourly = inc / 2080  # annual → hourly
                    cost_ratio = mode_cost / max(hourly, 0.01)
                    cost_adj[hx] = max(1.0 - min(cost_ratio, 0.5), 0.5)
        else:
            cost_adj = {hx: 1.0 for hx in self.hex_ids}

        scores: Dict[str, float] = {}
        for src_hex, dest_dict in self._travel_times.items():
            acc = 0.0
            ca  = cost_adj.get(src_hex, 1.0)
            for dest_hex, t_min in dest_dict.items():
                m = mass_values.get(dest_hex, 0.0)
                if m <= 0 or t_min <= 0:
                    continue
                acc += m * np.exp(-beta * t_min) * ca
            scores[src_hex] = acc

        result = pd.Series(scores).reindex(self.hex_ids).fillna(0)
        self._accessibility = result
        return result


# ---------------------------------------------------------------------------
# PCI Calculator
# ---------------------------------------------------------------------------

class TopographicPCICalculator:
    """
    Converts Hansen accessibility into a normalised 0-100 PCI score
    with an optional active-streets bonus.

    PCI_i = Normalise( A_i × (1 + λ × ActiveStreet_i) )
    """

    def __init__(
        self,
        grid: HexGrid,
        hansen_model: HansenAccessibilityModel,
        mass_calculator: MassCalculator,
    ):
        self.grid  = grid
        self.hansen = hansen_model
        self.mass   = mass_calculator
        self.hex_ids = grid.gdf["hex_id"].tolist()
        self._pci: Optional[pd.Series] = None

    def compute_pci(
        self,
        active_lambda: float = 0.30,
        mask_parks: bool = False,
        park_threshold: float = 0.90,
    ) -> pd.Series:
        """
        Compute final PCI scores.

        Parameters
        ----------
        active_lambda  : weight for active street bonus [0, 1]
        mask_parks     : exclude hexes that are mostly park area
        park_threshold : park coverage fraction above which to mask
        """
        if self.hansen._accessibility is None:
            raise RuntimeError("Call hansen_model.compute_accessibility() first.")

        acc = self.hansen._accessibility.copy()

        # Active street bonus
        if active_lambda > 0 and "active_street_score" in self.grid.gdf.columns:
            active = self.grid.gdf.set_index("hex_id")["active_street_score"]
            active = active.reindex(self.hex_ids).fillna(0)
            acc = acc * (1 + active_lambda * active)
        elif active_lambda > 0:
            # Compute active street score from network
            active = self._compute_active_street_score()
            self.grid.attach_data(active, "active_street_score")
            acc = acc * (1 + active_lambda * active)

        # Park masking
        if mask_parks and "parks_norm" in self.grid.gdf.columns:
            park_cover = self.grid.gdf.set_index("hex_id")["parks_norm"]
            mask = park_cover.reindex(self.hex_ids) >= park_threshold
            acc[mask] = np.nan

        # Normalise to [0, 100]
        valid = acc.dropna()
        if len(valid) == 0 or valid.max() == valid.min():
            pci = acc.fillna(0) * 0
        else:
            pci = (acc - valid.min()) / (valid.max() - valid.min()) * 100

        self._pci = pci
        return pci

    def _compute_active_street_score(self) -> pd.Series:
        """
        Proxy for active street connectivity: mean degree of nearby network
        nodes (more intersections → more walkable street grid).
        """
        G = self.net.networks.get("walk") if hasattr(self, "net") \
            else self.hansen.net.networks.get("walk")
        if G is None:
            return pd.Series(0.0, index=self.hex_ids)

        centroids = self.grid.centroids
        scores = {}
        for _, row in centroids.iterrows():
            try:
                node = ox.nearest_nodes(G, row.geometry.x, row.geometry.y)
                degree = G.degree(node)
                scores[row["hex_id"]] = float(degree)
            except Exception:
                scores[row["hex_id"]] = 0.0

        series = pd.Series(scores).reindex(self.hex_ids).fillna(0)
        rng = series.max() - series.min()
        if rng > 0:
            series = (series - series.min()) / rng
        return series

    def compute_city_summary(self) -> dict:
        """Return a dict of city-wide statistics."""
        if self._pci is None:
            raise RuntimeError("Call compute_pci() first.")
        valid = self._pci.dropna()
        grid_valid = self.grid.gdf[self.grid.gdf["PCI"].notna()] \
            if "PCI" in self.grid.gdf.columns else self.grid.gdf
        total_area = grid_valid["area_m2"].sum() if "area_m2" in grid_valid.columns else np.nan
        weighted_pci = (
            (grid_valid["PCI"] * grid_valid["area_m2"]).sum() / total_area
            if not np.isnan(total_area) else valid.mean()
        )
        return {
            "city_pci":    round(float(weighted_pci), 2),
            "mean":        round(float(valid.mean()), 2),
            "median":      round(float(valid.median()), 2),
            "std":         round(float(valid.std()), 2),
            "p25":         round(float(valid.quantile(0.25)), 2),
            "p75":         round(float(valid.quantile(0.75)), 2),
            "gini":        round(float(self._gini(valid)), 3),
            "n_hexagons":  int(len(valid)),
            "area_km2":    round(float(total_area / 1e6), 2) if not np.isnan(total_area) else None,
        }

    @staticmethod
    def _gini(x: pd.Series) -> float:
        arr = np.sort(x.dropna().values)
        n = len(arr)
        if n == 0 or arr.sum() == 0:
            return 0.0
        idx = np.arange(1, n + 1)
        return float((2 * np.dot(idx, arr) / (n * arr.sum())) - (n + 1) / n)
